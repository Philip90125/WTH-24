import asyncio
import websockets
import threading
from queue import Queue
import time

# Global queue for sharing predictions between threads
prediction_queue = Queue()

# Event to signal when ESP32 is connected
esp32_connected = threading.Event()

# Function to run the websocket server
async def handle_websocket(websocket):
    """Handle WebSocket connections and send predictions."""
    print("ESP32 Connected!")
    esp32_connected.set()  # Signal that ESP32 is connected
    
    try:
        while True:
            # Get the latest prediction from the queue if available
            if not prediction_queue.empty():
                prediction = prediction_queue.get()
                message = f"{prediction['class']},{prediction['confidence']:.2f}"
                await websocket.send(message)
            await asyncio.sleep(0.1)  # Small delay to prevent overwhelming ESP32
    except websockets.exceptions.ConnectionClosed:
        print("ESP32 Disconnected!")
        esp32_connected.clear()  # Signal that ESP32 is disconnected

# Function to start the websocket server
async def run_websocket_server():
    async with websockets.serve(handle_websocket, "0.0.0.0", 8765):
        print("WebSocket server started on ws://0.0.0.0:8765")
        print("Waiting for ESP32 to connect...")
        await asyncio.Future()  # run forever

# Function to start the asyncio event loop in a separate thread
def start_websocket_thread():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(run_websocket_server())

# Modified main function that starts both AI and WebSocket
def main_with_websocket():
    # Start WebSocket server in a separate thread
    websocket_thread = threading.Thread(target=start_websocket_thread, daemon=True)
    websocket_thread.start()
    
    # Wait for ESP32 to connect
    print("Waiting for ESP32 connection...")
    esp32_connected.wait()
    print("ESP32 connected! Starting AI processing...")
    
    # Initialize webcam
    ip_cam_url = 'http://192.168.103.80:4747/video'
    cap = cv2.VideoCapture(ip_cam_url)
    if not cap.isOpened():
        print("Error: Could not open IP webcam feed")
        return

    # Load model
    print("Loading model...")
    try:
        model = load_model()
        print("Model loaded successfully!")
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    while True:
        # Check if ESP32 is still connected
        if not esp32_connected.is_set():
            print("ESP32 disconnected. Waiting for reconnection...")
            esp32_connected.wait()
            print("ESP32 reconnected! Resuming AI processing...")

        # Read frame from webcam
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame")
            break

        # Process frame
        processed_frame = process_frame(frame)

        # Make prediction
        predictions = model.predict(processed_frame)
        predicted_class = np.argmax(predictions[0])
        confidence = predictions[0][predicted_class]

        # Put prediction in queue for WebSocket server
        prediction_queue.put({
            'class': predicted_class,
            'confidence': confidence
        })

        # Draw predictions on frame
        text = f"Class {predicted_class}: {confidence:.2f}"
        cv2.putText(frame, text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Display frame
        cv2.imshow('Webcam Classification', frame)

        # Break loop on 'q' press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Cleanup
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    # Import your existing code
    from model_script import load_model, process_frame
    
    # Additional imports needed for WebSocket
    import cv2
    import numpy as np
    
    # Run the combined system
    main_with_websocket()