import tensorflow as tf
import numpy as np
import cv2

def load_model(model_path='keras_model.h5'):
    """Load the custom Keras model."""
    model = tf.keras.models.load_model(model_path)
    return model

def process_frame(frame, target_size=(224, 224)):
    """Process frame for model input."""
    # Convert BGR to RGB (OpenCV uses BGR by default)
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    
    # Resize frame to target size
    frame_resized = cv2.resize(frame_rgb, target_size)
    
    # Normalize the image
    frame_normalized = frame_resized / 255.0
    
    # Expand dimensions
    frame_expanded = np.expand_dims(frame_normalized, axis=0)
    
    return frame_expanded

def main():
    # Initialize webcam
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam")
        return

    # Load model
    print("Loading model...")
    try:
        model = load_model()
        print("Model loaded successfully!")
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    while True:
        # Read frame from webcam
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame")
            break

        # Process frame
        processed_frame = process_frame(frame)

        # Make prediction
        predictions = model.predict(processed_frame)
        predicted_class = np.argmax(predictions[0])
        confidence = predictions[0][predicted_class]

        # Draw predictions on frame
        text = f"Class {predicted_class}: {confidence:.2f}"
        cv2.putText(frame, text, (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        # Display frame
        cv2.imshow('Webcam Classification', frame)

        # Break loop on 'q' press
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Cleanup
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()